the face2faceindex program takes two parameters as input
    1. the .tri file
    2. the name of the output .face file

the faceindex2directededge program take one parameter, the .face file.

